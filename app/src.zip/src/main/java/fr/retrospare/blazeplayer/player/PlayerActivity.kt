package fr.retrospare.blazeplayer.player

import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.content.res.Configuration
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.DeviceInfo
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import dagger.hilt.android.AndroidEntryPoint
import fr.retrospare.blazeplayer.R
import fr.retrospare.blazeplayer.cast.VideoStreamServerManager
import fr.retrospare.blazeplayer.data.repository.MediaRepository
import fr.retrospare.blazeplayer.debug.CrashReporter
import fr.retrospare.blazeplayer.databinding.ActivityPlayerBinding
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * Écran de lecture vidéo.
 *
 * Architecture (Media3 1.9) : toute la lecture — locale ET Chromecast — passe par UN SEUL
 * [MediaItem], dont l'URI pointe vers notre propre relais HTTP local ([VideoStreamServerManager]),
 * jamais directement vers smb:// ou content://. C'est ce qui permet à [androidx.media3.cast.CastPlayer]
 * (construit dans [VideoPlaybackService]) de basculer tout seul entre local et distant — position
 * et sous-titres compris — sans la moindre reconstruction manuelle ici : on ne fait JAMAIS de
 * `setMediaItem()` spécifique au cast, on laisse Media3 s'en charger.
 */
@AndroidEntryPoint
class PlayerActivity : AppCompatActivity() {

    @Inject lateinit var dataStore: DataStore<Preferences>
    @Inject lateinit var mediaRepository: MediaRepository

    companion object {
        val SUB_LANG_CODES = listOf(null, "fra", "eng", "spa", "deu", "ita", "jpn", "por", "nld", "rus", "zho")
        val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val SEEK_LABELS = listOf("5s", "10s", "15s", "30s", "60s")
    }

    private lateinit var binding: ActivityPlayerBinding
    lateinit var player: Player
    /** Complété une fois que le MediaController est connecté à VideoPlaybackService et assigné à
     *  [player]. Permet de séquencer correctement le chargement des préférences (asynchrone via
     *  DataStore) avant toute mutation du player. */
    private val playerReady = CompletableDeferred<Unit>()
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private lateinit var audioManager: AudioManager

    private var prefSpeedIndex = 3
    private var prefResumeMode = 1
    private var prefAutoPlay = true
    private var prefSeekIndex = 1
    private var prefPip = false
    private var prefAudioLangIndex = 0
    private var prefRememberVolume = false

    private val uiHandler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { hideUI() }
    private var uiVisible = true
    private var mediaPath = ""
    private var mediaName = ""
    private var resumeHandled = false
    private var lastKnownIsRemote = false
    private var lastKnownLocalPosition = 0L
    private var lastKnownRemotePosition = 0L
    private var playNextCalled = false
    private var seekBarDragging = false
    // File d'attente de lecture (playlist "Jouer la playlist") : quand non vide, playNext()
    // enchaîne sur l'élément suivant de cette liste au lieu de chercher dans le même dossier local.
    private var videoQueuePaths: ArrayList<String> = arrayListOf()
    private var videoQueueNames: ArrayList<String> = arrayListOf()
    private var videoQueueIndex: Int = 0
    private var zoneTouching = false
    private var gestureStartY = 0f
    private var initialBrightness = 0.5f
    private var initialVolume = 0
    private var maxVolume = 0
    private var networkErrorDialogShown = false
    private var compatWarningShown = false
    private var hasEnteredPip = false
    private var videoStoppedByUser = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_FULLSCREEN)
        lifecycleScope.launch {
            val orientIdx = dataStore.data.first()[intPreferencesKey("orientation")] ?: 0
            requestedOrientation = when (orientIdx) {
                1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            }
        }

        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applyImmersiveMode()
        applyResponsivePlayerLayout()
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val systemBars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                binding.uiOverlay.setPadding(0, 0, 0, 0)
            } else {
                binding.uiOverlay.setPadding(0, systemBars.top, 0, systemBars.bottom)
            }
            insets
        }

        mediaPath = intent.getStringExtra("mediaPath") ?: return finish()
        intent.getStringArrayListExtra("queuePaths")?.let { videoQueuePaths = it }
        intent.getStringArrayListExtra("queueNames")?.let { videoQueueNames = it }
        videoQueueIndex = intent.getIntExtra("queueIndex", 0)
        mediaName = intent.getStringExtra("mediaName") ?: File(mediaPath).name

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goBackToHistory() }
        })

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        // Démarre tout de suite le relais HTTP local : le MediaItem construit plus bas en a besoin.
        try {
            VideoStreamServerManager.startServer(applicationContext, mediaPath)
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to start local video stream server for $mediaPath", e)
            android.widget.Toast.makeText(this, getString(R.string.error_loading_media), android.widget.Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Met l'audio en pause (sans arrêter le service ni sa notification) pour pouvoir la
        // relancer facilement une fois la vidéo terminée, au lieu de couper BlazePlayerService.
        pauseAudioPlaybackKeepingNotification()

        // Démarre VideoPlaybackService (ExoPlayer + CastPlayer + MediaSession vidéo). Toute erreur
        // ici était auparavant fatale ou silencieuse selon les appareils : on la loggue et on sort
        // proprement au lieu de laisser l'Activity attendre un player qui n'arrivera jamais.
        try {
            startService(android.content.Intent(this, VideoPlaybackService::class.java))
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to start VideoPlaybackService", e)
            android.widget.Toast.makeText(this, getString(R.string.error_loading_media), android.widget.Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val token = SessionToken(this, android.content.ComponentName(this, VideoPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture!!.addListener({
            try {
                player = controllerFuture!!.get()
                playerReady.complete(Unit)
            } catch (e: Exception) {
                CrashReporter.log(this, "MediaController connection failed for video service", e)
                if (!playerReady.isCompleted) playerReady.completeExceptionally(e)
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        android.widget.Toast.makeText(this, getString(R.string.error_loading_media), android.widget.Toast.LENGTH_LONG).show()
                        finish()
                    }
                }
            }
        }, MoreExecutors.directExecutor())

        binding.tvTitle.text = mediaName
        binding.tvCurrentTime.text = "0:00:00"
        binding.tvTotalTime.text = "0:00:00"

        setupControls()
        setupProgressBar()
        setupGestures()
        saveHistory()
        scheduleHide()

        // Charge les préférences puis les applique au player UNE FOIS que le MediaController est
        // prêt (séquencement explicite via CompletableDeferred).
        lifecycleScope.launch {
            val prefs = dataStore.data.first()
            prefSpeedIndex = prefs[intPreferencesKey("speed_index")] ?: 3
            prefResumeMode = prefs[intPreferencesKey("resume_mode")] ?: 1
            prefAutoPlay = prefs[booleanPreferencesKey("auto_play")] ?: true
            prefSeekIndex = prefs[intPreferencesKey("seek_time_index")] ?: 1
            prefPip = prefs[booleanPreferencesKey("pip")] ?: false
            prefAudioLangIndex = prefs[intPreferencesKey("audio_lang")] ?: 0
            prefRememberVolume = prefs[booleanPreferencesKey("remember_volume")] ?: false

            if (prefRememberVolume) {
                val savedVol = prefs[intPreferencesKey("saved_volume")] ?: -1
                if (savedVol >= 0) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, savedVol, 0)
            }

            binding.tvRewindLabel.text = "−${SEEK_LABELS.getOrElse(prefSeekIndex) { "10s" }}"
            binding.tvForwardLabel.text = "+${SEEK_LABELS.getOrElse(prefSeekIndex) { "10s" }}"

            val ready = try {
                withTimeoutOrNull(6_000) {
                    playerReady.await()
                    true
                } ?: false
            } catch (e: Exception) {
                CrashReporter.log(this@PlayerActivity, "Video player controller failed for $mediaPath", e)
                false
            }
            if (!ready || !::player.isInitialized) {
                CrashReporter.log(this@PlayerActivity, "Video player controller timeout for $mediaPath")
                android.widget.Toast.makeText(this@PlayerActivity, getString(R.string.error_loading_media), android.widget.Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            onPlayerReady()

            val audioLang = SUB_LANG_CODES.getOrNull(prefAudioLangIndex)
            applySubtitleTrackSelection()
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .apply { if (audioLang != null) setPreferredAudioLanguage(audioLang) }
                .build()
            player.setPlaybackSpeed(SPEEDS.getOrElse(prefSpeedIndex) { 1.0f })
            updateSpeedLabel()

            val savedMs = getSharedPreferences("blaze_positions", MODE_PRIVATE).getLong(mediaPath, 0L)
            val hasResumePosition = savedMs > 3000L
            val startPosition = when {
                // Mode "toujours reprendre" : on démarre directement à la dernière position.
                prefResumeMode == 0 && hasResumePosition -> savedMs
                // Mode "demander" : on doit laisser handleResume() afficher le modal.
                // Ne pas pré-positionner ici, sinon le dialogue est court-circuité.
                else -> 0L
            }
            resumeHandled = prefResumeMode != 1 && startPosition > 0L

            loadMedia(mediaPath, mediaName, startPosition)

            startProgressLoop()
        }

        // Extrait miniature vidéo en arrière-plan, bornée dans le temps. Sur SMB, le retriever
        // natif peut rester coincé longtemps : on ne doit jamais laisser ce job concurrencer la lecture.
        lifecycleScope.launch(Dispatchers.IO) {
            withTimeoutOrNull(2_000) {
                var smbDataSourceThumb: SmbMediaDataSource? = null
                val r = android.media.MediaMetadataRetriever()
                try {
                    when {
                        mediaPath.startsWith("smb://") -> {
                            smbDataSourceThumb = SmbMediaDataSource(mediaPath)
                            r.setDataSource(smbDataSourceThumb)
                        }
                        mediaPath.startsWith("content://") -> r.setDataSource(this@PlayerActivity, Uri.parse(mediaPath))
                        else -> r.setDataSource(mediaPath)
                    }
                    val frame = r.getFrameAtTime(10_000_000)
                    frame?.let {
                        val scale = 256f / maxOf(it.width, it.height)
                        if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(it, (it.width * scale).toInt(), (it.height * scale).toInt(), true).also { _ -> it.recycle() }
                        else it
                    }
                } catch (e: Exception) {
                    CrashReporter.log(this@PlayerActivity, "Thumbnail extraction failed for $mediaPath", e)
                } finally {
                    try { r.release() } catch (_: Exception) {}
                    try { smbDataSourceThumb?.close() } catch (_: Exception) {}
                }
            } ?: CrashReporter.log(this@PlayerActivity, "Thumbnail extraction timeout for $mediaPath")
        }
    }

    /** Active toujours les pistes texte lorsqu'un MediaItem contient un WebVTT sidecar.
     *  Les deux anciens réglages globaux (sous-titres par défaut et langue préférée) ont été
     *  supprimés : on ne bloque plus jamais TRACK_TYPE_TEXT à cause d'une préférence obsolète. */
    private fun applySubtitleTrackSelection() {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .build()
    }

    private fun guessVideoMimeType(path: String): String {
        return when (path.substringBefore('?').substringAfterLast('.', "").lowercase()) {
            "mp4", "m4v" -> androidx.media3.common.MimeTypes.VIDEO_MP4
            "mkv" -> "video/x-matroska"
            "webm" -> androidx.media3.common.MimeTypes.VIDEO_WEBM
            "mov" -> "video/quicktime"
            "ts", "m2ts", "mts" -> "video/mp2t"
            else -> androidx.media3.common.MimeTypes.VIDEO_MP4
        }
    }

    /** Construit le MediaItem unique utilisé pour la lecture — valide et identique pour le local
     *  ET le Cast (URL réseau dans les deux cas, cf. doc de VideoPlaybackService). Attache la
     *  piste sous-titres depuis le cache si elle est déjà disponible. */
    private fun buildMediaItem(path: String, name: String): MediaItem {
        VideoStreamServerManager.startServer(applicationContext, path)
        val url = VideoStreamServerManager.getStreamUrl() ?: path
        val builder = MediaItem.Builder()
            .setUri(Uri.parse(url))
            .setMediaId(path)
            .setMimeType(guessVideoMimeType(path))
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(name)
                    .setMediaType(MediaMetadata.MEDIA_TYPE_MOVIE)
                    .build()
            )
        return builder.build()
    }

    /** Point d'entrée UNIQUE pour charger un média. API Player standard uniquement :
     *  setMediaItem -> prepare -> play. Pas de RemoteMediaClient, pas de MediaQueueItem manuel. */
    private fun loadMedia(path: String, name: String, positionMs: Long = 0L) {
        videoStoppedByUser = false
        val item = buildMediaItem(path, name)
        android.util.Log.i(
            "CAST",
            "LOAD média path=$path uri=${item.localConfiguration?.uri} positionMs=$positionMs remote=${player.deviceInfo.playbackType == DeviceInfo.PLAYBACK_TYPE_REMOTE}"
        )
        // IMPORTANT : ne PAS appeler player.stop() ici. Dans cette app, le Player est exposé
        // via MediaSessionService ; stop() est interprété comme une commande STOP de session et
        // peut arrêter VideoPlaybackService pendant que CastPlayer est encore actif, ce qui
        // provoque des crashs quelques secondes après le début du cast.
        player.setMediaItem(item, positionMs)
        player.prepare()
        applySubtitleTrackSelection()
        player.play()
        loadNotificationArtwork(path)
    }

    /** Récupère la miniature (locale ou réseau, via le même cache que le reste de l'app) et
     *  l'ajoute aux métadonnées du média déjà en lecture — sans bloquer le lancement de la
     *  vidéo, qui doit rester instantané. `replaceMediaItem` met à jour les métadonnées sans
     *  interrompre la lecture en cours ; c'est ce que lit `DefaultMediaNotificationProvider`
     *  pour afficher l'image dans la notification Android. */
    private fun loadNotificationArtwork(path: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            // Miniature notification vidéo réseau : on tente d'abord le cache/ThumbnailUtils
            // habituel, puis un fallback via l'URL HTTP locale déjà servie au player. Sans ce
            // fallback, une extraction SMB directe lente ou refusée laissait souvent la notification
            // Android sans artwork pour les vidéos réseau.
            val bitmap = try {
                withTimeoutOrNull(3_500) {
                    fr.retrospare.blazeplayer.ui.ThumbnailUtils.getThumbnailBitmap(applicationContext, path, if (path.startsWith("smb://")) 10_000_000L else 5_000_000L)
                }
            } catch (e: Exception) {
                fr.retrospare.blazeplayer.debug.CrashReporter.log(applicationContext, "Video notification thumbnail primary extraction failed", e)
                null
            } ?: try {
                val streamUrl = fr.retrospare.blazeplayer.cast.VideoStreamServerManager.getStreamUrl()
                if (streamUrl != null && (path.startsWith("smb://") || path.startsWith("ftp://") || path.startsWith("http://") || path.startsWith("https://"))) {
                    android.media.MediaMetadataRetriever().use { retriever ->
                        retriever.setDataSource(applicationContext, android.net.Uri.parse(streamUrl))
                        retriever.getFrameAtTime(10_000_000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.frameAtTime
                    }
                } else null
            } catch (e: Exception) {
                fr.retrospare.blazeplayer.debug.CrashReporter.log(applicationContext, "Video notification thumbnail HTTP fallback failed", e)
                null
            } ?: return@launch

            val artworkData = try {
                val scaled = if (bitmap.width > 512 || bitmap.height > 512) {
                    val ratio = 512f / maxOf(bitmap.width, bitmap.height)
                    android.graphics.Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
                } else bitmap
                val stream = java.io.ByteArrayOutputStream()
                scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 86, stream)
                stream.toByteArray()
            } catch (e: Exception) {
                fr.retrospare.blazeplayer.debug.CrashReporter.log(applicationContext, "Video notification thumbnail encoding failed", e)
                null
            } ?: return@launch

            withContext(Dispatchers.Main) {
                // Le média en cours a pu changer entre-temps (suivant/précédent rapide) : ne
                // met à jour que si on est toujours sur le même fichier.
                val current = player.currentMediaItem ?: return@withContext
                if (current.mediaId != path) return@withContext
                // Envoyée au service (qui détient l'instance réelle du player) plutôt que
                // d'appeler replaceMediaItem() directement ici sur le MediaController.
                val args = android.os.Bundle().apply {
                    putString(fr.retrospare.blazeplayer.player.VideoPlaybackService.EXTRA_ARTWORK_MEDIA_ID, path)
                    putByteArray(fr.retrospare.blazeplayer.player.VideoPlaybackService.EXTRA_ARTWORK_DATA, artworkData)
                }
                val future = (player as? MediaController)?.sendCustomCommand(
                    androidx.media3.session.SessionCommand(
                        fr.retrospare.blazeplayer.player.VideoPlaybackService.CUSTOM_COMMAND_SET_ARTWORK,
                        android.os.Bundle.EMPTY
                    ),
                    args
                )
                future?.addListener({
                    try {
                        val result = future.get()
                        if (result.resultCode != androidx.media3.session.SessionResult.RESULT_SUCCESS) {
                            android.util.Log.w("PlayerActivity", "Artwork command failed result=${result.resultCode}")
                        }
                    } catch (e: Exception) {
                        fr.retrospare.blazeplayer.debug.CrashReporter.log(applicationContext, "Video notification artwork command failed", e)
                    }
                }, androidx.core.content.ContextCompat.getMainExecutor(this@PlayerActivity))
            }
        }
    }

    private var currentRatioIndex = 0
    // "by lazy" : évalué au premier accès plutôt qu'à la construction de l'Activity. Les
    // getString() ici s'exécutaient sinon dans le constructeur, avant que le Context ne soit
    // prêt (avant attachBaseContext()/onCreate()) — ce qui provoquait un crash immédiat au clic
    // sur une vidéo ("Attempt to invoke virtual method getResources() on a null object
    // reference"), avant même que l'ANR ne puisse se manifester.
    private val ratioLabels by lazy { listOf(getString(R.string.ratio_auto), getString(R.string.ratio_zoom), getString(R.string.ratio_stretched), getString(R.string.ratio_full)) }

    private fun cycleAspectRatio() {
        currentRatioIndex = (currentRatioIndex + 1) % ratioLabels.size
        binding.playerView.resizeMode = when (currentRatioIndex) {
            0 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
            1 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
        }
        binding.seekIndicator.text = ratioLabels[currentRatioIndex]
        binding.seekIndicator.visibility = View.VISIBLE
        uiHandler.removeCallbacksAndMessages(null)
        uiHandler.postDelayed({ binding.seekIndicator.visibility = View.GONE }, 2000)
    }

    private fun showAudioTracks() {
        val tracks = player.currentTracks
        val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
        if (audioGroups.isEmpty()) {
            android.widget.Toast.makeText(this, getString(R.string.toast_no_audio_track), android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val labels = audioGroups.mapIndexed { i, group ->
            val format = group.getTrackFormat(0)
            val baseLang = format.language ?: getString(R.string.track_generic)
            val label = format.label
            when {
                !label.isNullOrBlank() -> label
                audioGroups.count { it.getTrackFormat(0).language == format.language } > 1 -> "$baseLang ${i + 1}"
                else -> baseLang
            }
        }
        val selectedIndex = audioGroups.indexOfFirst { it.isSelected }
        showTrackSelector(getString(R.string.audio_track), labels, selectedIndex) { i ->
            val override = TrackSelectionOverride(audioGroups[i].mediaTrackGroup, 0)
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                .addOverride(override)
                .build()
        }
    }

    /** Affiche un sélecteur de piste (audio ou sous-titre) sous forme de bottom sheet custom. */
    private fun showTrackSelector(title: String, labels: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_track_selector, null)
        dialogView.findViewById<android.widget.TextView>(R.id.tvTrackDialogTitle).text = title
        val recycler = dialogView.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recyclerTracks)
        recycler.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)

        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        dialog.setContentView(dialogView)

        recycler.adapter = object : androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {
            override fun getItemCount() = labels.size
            override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): androidx.recyclerview.widget.RecyclerView.ViewHolder {
                val v = layoutInflater.inflate(R.layout.item_track_option, parent, false)
                return object : androidx.recyclerview.widget.RecyclerView.ViewHolder(v) {}
            }
            override fun onBindViewHolder(holder: androidx.recyclerview.widget.RecyclerView.ViewHolder, position: Int) {
                val v = holder.itemView
                v.findViewById<android.widget.TextView>(R.id.tvTrackLabel).text = labels[position]
                v.findViewById<android.widget.ImageView>(R.id.ivTrackCheck).visibility =
                    if (position == selectedIndex) View.VISIBLE else View.INVISIBLE
                v.setOnClickListener { onSelect(position); dialog.dismiss() }
            }
        }
        dialog.show()
    }

    private fun showSubtitles() {
        val tracks = player.currentTracks
        val subGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
        val labels = mutableListOf(getString(R.string.subtitles_disabled))
        subGroups.forEachIndexed { i, group ->
            val format = group.getTrackFormat(0)
            val baseLang = format.language ?: "ST"
            val label = format.label
            labels.add(when {
                !label.isNullOrBlank() -> label
                subGroups.count { it.getTrackFormat(0).language == format.language } > 1 -> "$baseLang ${i + 1}"
                else -> baseLang
            })
        }
        val selectedIndex = if (subGroups.none { it.isSelected }) 0 else subGroups.indexOfFirst { it.isSelected } + 1
        showTrackSelector(getString(R.string.dialog_title_subtitles), labels, selectedIndex) { i ->
            if (i == 0) {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                    .build()
            } else {
                val selectedGroup = subGroups[i - 1]
                val override = TrackSelectionOverride(selectedGroup.mediaTrackGroup, 0)
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                    .addOverride(override)
                    .build()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (::player.isInitialized) {
            binding.playerView.player = player
        }
    }

    override fun onResume() {
        super.onResume()
        applyImmersiveMode()
    }

    override fun onPause() {
        super.onPause()
        if (!::player.isInitialized) return
        if (prefPip && player.isPlaying) enterPipIfEnabled()
    }

    override fun onStop() {
        super.onStop()
        if (isInPictureInPictureMode) return
        if (!::player.isInitialized) return
        if (prefRememberVolume) {
            val vol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            lifecycleScope.launch { dataStore.edit { it[intPreferencesKey("saved_volume")] = vol } }
        }
        val pos = player.currentPosition
        if (mediaPath.isNotEmpty() && pos > 0) {
            getSharedPreferences("blaze_positions", MODE_PRIVATE).edit().putLong(mediaPath, pos).apply()
            lifecycleScope.launch { mediaRepository.updateProgress(mediaPath, pos / 1000) }
        }
        // Home / app switch : on détache uniquement la surface pour éviter les leaks UI.
        // La lecture continue dans VideoPlaybackService ; si le PiP est activé, Android garde
        // la surface PiP. L'arrêt réel se fait dans VideoPlaybackService.onTaskRemoved() lors
        // du swipe depuis les tâches récentes.
        binding.playerView.player = null
    }

    override fun onDestroy() {
        try { binding.playerView.player = null } catch (_: Exception) {}
        super.onDestroy()
        uiHandler.removeCallbacksAndMessages(null)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        val isCasting = if (::player.isInitialized) player.deviceInfo.playbackType == DeviceInfo.PLAYBACK_TYPE_REMOTE else false
        // Si l'utilisateur ferme la fenêtre Picture-in-Picture avec la croix système, Android
        // détruit l'Activity PiP sans passer par notre bouton Stop. Dans ce cas seulement, on
        // coupe la lecture et le service pour supprimer immédiatement la notification vidéo.
        if (hasEnteredPip && !isChangingConfigurations) {
            try {
                if (::player.isInitialized) {
                    player.pause()
                    player.stop()
                    player.clearMediaItems()
                }
            } catch (e: Exception) {
                CrashReporter.log(this, "Failed to stop video after PiP close", e)
            }
            try { stopService(android.content.Intent(this, VideoPlaybackService::class.java)) } catch (e: Exception) {
                CrashReporter.log(this, "Failed to stop VideoPlaybackService after PiP close", e)
            }
            try { VideoStreamServerManager.stopServer() } catch (e: Exception) {
                CrashReporter.log(this, "Failed to stop local video stream server after PiP close", e)
            }
        } else if (!isCasting) VideoStreamServerManager.stopServer()
        // Ne pas relancer artificiellement le service audio ici : après un swipe de fermeture,
        // cela recréait une notification audio fantôme. La reprise audio doit venir d'une action
        // utilisateur explicite ou d'un contrôleur déjà connecté, pas de la destruction du player.
    }

    /** Met en pause la lecture audio (BlazePlayerService) sans arrêter le service ni sa
     *  notification, pour pouvoir la relancer facilement une fois la vidéo terminée. */
    private fun pauseAudioPlaybackKeepingNotification() {
        try {
            val audioToken = SessionToken(this, android.content.ComponentName(this, BlazePlayerService::class.java))
            val audioControllerFuture = MediaController.Builder(this, audioToken).buildAsync()
            audioControllerFuture.addListener({
                try {
                    val controller = audioControllerFuture.get()
                    if (controller.isPlaying) controller.pause()
                } catch (e: Exception) {
                    android.util.Log.w("PlayerActivity", "pauseAudioPlaybackKeepingNotification failed", e)
                } finally {
                    MediaController.releaseFuture(audioControllerFuture)
                }
            }, MoreExecutors.directExecutor())
        } catch (e: Exception) {
            android.util.Log.w("PlayerActivity", "pauseAudioPlaybackKeepingNotification failed", e)
        }
    }

    /** Avertissement informatif (non bloquant) si le Chromecast connecté est probablement
     *  incompatible avec cette vidéo — la bascule automatique de CastPlayer a de toute façon déjà
     *  démarré à ce stade, donc on informe plutôt que d'essayer d'intercepter. */
    private fun warnIfIncompatible(modelName: String?) {
        if (compatWarningShown) return
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val info = withTimeoutOrNull(2_000) {
                    VideoMetadataExtractor.extractLight(applicationContext, mediaPath)
                } ?: VideoTechnicalInfo()
                val reason = fr.retrospare.blazeplayer.cast.ChromecastCompatibility.incompatibilityReason(info, modelName)
                if (reason != null) {
                    compatWarningShown = true
                    withContext(Dispatchers.Main) {
                        if (isDestroyed || isFinishing) return@withContext
                        android.widget.Toast.makeText(
                            this@PlayerActivity,
                            getString(R.string.toast_chromecast_incompatible, modelName ?: getString(R.string.unknown_model), reason),
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } catch (e: Exception) {
                CrashReporter.log(this@PlayerActivity, "Chromecast compatibility check failed for $mediaPath", e)
            }
        }
    }

    private fun onPlayerReady() {
        binding.playerView.player = player

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                android.util.Log.e(
                    "PlayerActivity",
                    "onPlayerError code=${error.errorCode} name=${PlaybackException.getErrorCodeName(error.errorCode)} " +
                        "message=${error.message} cause=${error.cause}",
                    error
                )
                val isCasting = ::player.isInitialized && player.deviceInfo.playbackType == DeviceInfo.PLAYBACK_TYPE_REMOTE
                if (mediaPath.startsWith("smb://") || mediaPath.startsWith("ftp://") || isCasting) {
                    runOnUiThread { showNetworkErrorDialog() }
                }
            }

            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                runOnUiThread { updatePipParamsIfSupported() }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                runOnUiThread {
                    updatePlayPauseBtn(isPlaying)
                    updatePipParamsIfSupported()
                    if (isPlaying) {
                        scheduleHide()
                        if (!resumeHandled) handleResume()
                    } else {
                        cancelHide()
                        showUI()
                    }
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                val stateName = when (state) {
                    Player.STATE_IDLE -> "STATE_IDLE"
                    Player.STATE_BUFFERING -> "STATE_BUFFERING"
                    Player.STATE_READY -> "STATE_READY"
                    Player.STATE_ENDED -> "STATE_ENDED"
                    else -> "UNKNOWN($state)"
                }
                android.util.Log.i("CAST", "onPlaybackStateChanged: $stateName (isRemote=${player.deviceInfo.playbackType == DeviceInfo.PLAYBACK_TYPE_REMOTE})")
                if (state == Player.STATE_ENDED) {
                    runOnUiThread {
                        updatePlayPauseBtn(false)
                        cancelHide()
                        showUI()
                        if (!playNextCalled) {
                            playNextCalled = true
                            if (prefAutoPlay) playNext()
                        }
                    }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                android.util.Log.i("CAST", "onMediaItemTransition: mediaId=${mediaItem?.mediaId} uri=${mediaItem?.localConfiguration?.uri} reason=$reason")
            }

            override fun onDeviceInfoChanged(deviceInfo: DeviceInfo) {
                val isRemote = deviceInfo.playbackType == DeviceInfo.PLAYBACK_TYPE_REMOTE
                binding.castBlackout.visibility = if (isRemote) View.VISIBLE else View.GONE
                cancelHide()
                showUI()

                // Media3 1.9 CastPlayer transfère automatiquement l'état entre ExoPlayer et
                // RemoteCastPlayer. Ne jamais recharger ici : recharger pendant la transition Cast
                // créait des LOAD concurrents, tracks=[] et des retours Surface invalides.
                if (isRemote != lastKnownIsRemote) {
                    lastKnownIsRemote = isRemote
                    android.util.Log.i("CAST", "Transition ${if (isRemote) "vers" else "depuis"} Cast détectée")
                    applySubtitleTrackSelection()
                }

                if (isRemote) {
                    val session = try {
                        com.google.android.gms.cast.framework.CastContext.getSharedInstance(applicationContext)
                            .sessionManager.currentCastSession
                    } catch (e: Exception) { null }
                    val deviceName = session?.castDevice?.friendlyName
                    binding.tvSubtitle.text = if (deviceName != null) getString(R.string.casting_on_device, deviceName) else getString(R.string.casting_chromecast)
                    binding.tvSubtitle.visibility = View.VISIBLE
                    warnIfIncompatible(session?.castDevice?.modelName)
                } else {
                    binding.tvSubtitle.visibility = View.GONE
                }
            }
        })
    }

    private fun handleResume() {
        resumeHandled = true
        if (prefResumeMode == 2) return
        val savedMs = getSharedPreferences("blaze_positions", MODE_PRIVATE).getLong(mediaPath, 0L)
        if (savedMs <= 3000L) return
        when (prefResumeMode) {
            0 -> player.seekTo(savedMs)
            1 -> android.app.AlertDialog.Builder(this)
                .setTitle(getString(R.string.settings_resume_playback))
                .setMessage(getString(R.string.dialog_resume_message, savedMs / 60000, (savedMs / 1000) % 60))
                .setPositiveButton(getString(R.string.action_resume)) { _, _ -> player.seekTo(savedMs) }
                .setNegativeButton(getString(R.string.action_from_beginning)) { _, _ -> player.seekTo(0) }
                .show()
        }
    }

    private fun goBackToHistory() {
        if (mediaPath.startsWith("smb://") || mediaPath.startsWith("ftp://")) {
            val intent = android.content.Intent(this, fr.retrospare.blazeplayer.MainActivity::class.java)
            intent.flags = android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            intent.putExtra("requestedTab", 2)
            startActivity(intent)
            finish()
        } else {
            finish()
        }
    }

    private fun showNetworkErrorDialog() {
        if (networkErrorDialogShown) return
        networkErrorDialogShown = true
        android.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.dialog_title_network_error))
            .setMessage(getString(R.string.dialog_network_error_message))
            .setCancelable(false)
            .setPositiveButton(getString(R.string.action_retry)) { _, _ ->
                networkErrorDialogShown = false
                player.prepare()
                player.play()
            }
            .setNegativeButton(getString(R.string.action_quit)) { _, _ -> finish() }
            .show()
    }

    private fun showQuickVideoInfo() {
        val duration = if (::player.isInitialized && player.duration > 0) formatTime(player.duration) else "--:--"
        val sizeLabel = if (mediaPath.startsWith("smb://") || mediaPath.startsWith("ftp://")) "Réseau" else "Local"
        binding.seekIndicator.text = "$mediaName • $duration • $sizeLabel"
        binding.seekIndicator.visibility = View.VISIBLE
        uiHandler.postDelayed({ binding.seekIndicator.visibility = View.GONE }, 2600)
    }

    private fun applyImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.hide(WindowInsetsCompat.Type.navigationBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyImmersiveMode()
        applyResponsivePlayerLayout()
    }


    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /** Ajustements fins du layout vidéo selon l'orientation.
     *
     * Portrait : les boutons -10/+10 sont placés plus près du vrai milieu entre le bouton Play
     * et les barres tactiles latérales, pour éviter l'impression de contrôles éparpillés.
     * Paysage : la timeline est volontairement plus courte, et les barres tactiles remontent un
     * peu en se rapprochant du centre afin de ne plus chevaucher les contrôles système/lecteur.
     */
    private fun applyResponsivePlayerLayout() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        (binding.btnPlayPause.layoutParams as? LinearLayout.LayoutParams)?.let { lp ->
            val margin = if (landscape) dp(34) else dp(18)
            lp.marginStart = margin
            lp.marginEnd = margin
            binding.btnPlayPause.layoutParams = lp
        }

        binding.bottomControlsContainer.setPadding(
            if (landscape) dp(54) else dp(14),
            binding.bottomControlsContainer.paddingTop,
            if (landscape) dp(54) else dp(14),
            if (landscape) dp(14) else dp(18)
        )

        binding.timelineRow.setPadding(
            if (landscape) dp(10) else dp(2),
            binding.timelineRow.paddingTop,
            if (landscape) dp(10) else dp(2),
            binding.timelineRow.paddingBottom
        )

        fun tuneTouchPanel(panel: View, gravitySide: Int) {
            val lp = (panel.layoutParams as? FrameLayout.LayoutParams) ?: return
            lp.gravity = android.view.Gravity.CENTER_VERTICAL or gravitySide
            if (gravitySide == android.view.Gravity.START) {
                lp.marginStart = if (landscape) dp(72) else dp(24)
                lp.marginEnd = 0
            } else {
                lp.marginEnd = if (landscape) dp(72) else dp(24)
                lp.marginStart = 0
            }
            panel.translationY = if (landscape) -dp(38).toFloat() else 0f
            panel.layoutParams = lp
        }
        tuneTouchPanel(binding.touchZoneLeft, android.view.Gravity.START)
        tuneTouchPanel(binding.touchZoneRight, android.view.Gravity.END)
    }

    private fun setupControls() {
        binding.btnBack.setOnClickListener { goBackToHistory() }

        binding.btnPlayPause.setOnClickListener {
            if (videoStoppedByUser) {
                lifecycleScope.launch { restartVideoAfterUserStop() }
                return@setOnClickListener
            }
            if (!::player.isInitialized) return@setOnClickListener
            if (player.isPlaying) player.pause() else player.play()
            scheduleHide()
        }

        binding.btnRewind.setOnClickListener {
            if (!::player.isInitialized) return@setOnClickListener
            player.seekTo((player.currentPosition - seekMs()).coerceAtLeast(0))
            scheduleHide()
        }

        binding.btnForward.setOnClickListener {
            if (!::player.isInitialized) return@setOnClickListener
            val dur = player.duration.takeIf { it > 0 } ?: return@setOnClickListener
            player.seekTo((player.currentPosition + seekMs()).coerceAtMost(dur))
            scheduleHide()
        }

        binding.btnPrevious.setOnClickListener { scheduleHide(); playPrevious() }
        binding.btnNext.setOnClickListener { scheduleHide(); playNext() }

        binding.btnRatio.setOnClickListener { scheduleHide(); cycleAspectRatio() }
        binding.btnSeekInfo.setOnClickListener { scheduleHide(); showQuickVideoInfo() }
        binding.btnAudio.setOnClickListener { scheduleHide(); showAudioTracks() }
        binding.btnSubtitles.setOnClickListener { scheduleHide(); showSubtitles() }
        binding.btnSpeed.setOnClickListener { scheduleHide(); cyclePlaybackSpeed() }
        binding.btnHeaderCast.setOnClickListener {
            scheduleHide()
            binding.seekIndicator.text = "Chromecast disponible depuis le bouton Cast système"
            binding.seekIndicator.visibility = View.VISIBLE
            uiHandler.postDelayed({ binding.seekIndicator.visibility = View.GONE }, 2000)
        }
        binding.uiOverlay.setOnClickListener { if (uiVisible) hideUI() else showUI() }
        binding.playerView.setOnClickListener { if (uiVisible) hideUI() else showUI() }

        // Stop réel : coupe la session vidéo, remet l'écran du lecteur au noir et laisse
        // VideoPlaybackService se détruire pour retirer immédiatement la notification Android.
        binding.btnStop.setOnClickListener {
            stopVideoPlaybackFromUi()
        }
    }


    /**
     * Bouton STOP du lecteur vidéo.
     *
     * Comportement attendu : contrairement au bouton Home, c'est une fermeture explicite de la
     * lecture. On ne revient pas simplement à 0 en pause : on supprime la surface vidéo pour que
     * l'écran devienne noir, on vide la session Media3, on coupe le relais HTTP local et on arrête
     * VideoPlaybackService afin que la notification Android disparaisse.
     */
    private fun stopVideoPlaybackFromUi() {
        cancelHide()
        videoStoppedByUser = true
        try {
            binding.playerView.player = null
            binding.playerView.setShutterBackgroundColor(android.graphics.Color.BLACK)
            binding.playerView.setBackgroundColor(android.graphics.Color.BLACK)
            binding.tvCurrentTime.text = "0:00:00"
            binding.tvTotalTime.text = "0:00:00"
            binding.progressFill.layoutParams.width = 0
            binding.progressFill.requestLayout()
            binding.progressThumb.translationX = 0f
            binding.progressBuffer.layoutParams.width = 0
            binding.progressBuffer.requestLayout()
            binding.ivPlayPause.setImageResource(R.drawable.ic_play)
            hideUI()
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to reset video UI on stop", e)
        }

        if (::player.isInitialized) {
            try {
                player.pause()
                player.stop()
                player.clearMediaItems()
            } catch (e: Exception) {
                CrashReporter.log(this, "Failed to stop video player from stop button", e)
            }
        }

        try {
            VideoStreamServerManager.stopServer()
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to stop local video stream server from stop button", e)
        }

        try {
            stopService(android.content.Intent(this, VideoPlaybackService::class.java))
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to stop VideoPlaybackService from stop button", e)
        }
    }

    private fun updateSpeedLabel() {
        val speed = SPEEDS.getOrElse(prefSpeedIndex) { 1.0f }
        binding.tvSpeedValue.text = String.format(Locale.US, "%.2f×", speed)
    }

    private fun cyclePlaybackSpeed() {
        if (!::player.isInitialized) return
        prefSpeedIndex = (prefSpeedIndex + 1) % SPEEDS.size
        val speed = SPEEDS.getOrElse(prefSpeedIndex) { 1.0f }
        player.setPlaybackSpeed(speed)
        updateSpeedLabel()
        binding.seekIndicator.text = String.format(Locale.US, "%.2f×", speed)
        binding.seekIndicator.visibility = View.VISIBLE
        uiHandler.postDelayed({ binding.seekIndicator.visibility = View.GONE }, 1400)
        lifecycleScope.launch {
            dataStore.edit { it[intPreferencesKey("speed_index")] = prefSpeedIndex }
        }
    }

    private fun seekMs() = when (prefSeekIndex) {
        0 -> 5_000L; 1 -> 10_000L; 2 -> 15_000L; 3 -> 30_000L; 4 -> 60_000L; else -> 10_000L
    }

    private fun setupProgressBar() {
        binding.progressContainer.setOnTouchListener { _, ev ->
            if (!::player.isInitialized) return@setOnTouchListener true
            val dur = player.duration.takeIf { it > 0 } ?: return@setOnTouchListener true
            val w = binding.progressContainer.width.toFloat().coerceAtLeast(1f)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    seekBarDragging = true; cancelHide()
                    player.seekTo((ev.x / w * dur).toLong().coerceIn(0, dur))
                    updateProgressUI(player.currentPosition, dur)
                }
                MotionEvent.ACTION_MOVE -> {
                    val ms = (ev.x / w * dur).toLong().coerceIn(0, dur)
                    player.seekTo(ms)
                    updateProgressUI(ms, dur)
                    binding.seekIndicator.visibility = View.VISIBLE
                    binding.seekIndicator.text = formatTime(ms)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    seekBarDragging = false
                    binding.seekIndicator.visibility = View.GONE
                    player.play()
                    scheduleHide()
                }
            }
            true
        }
    }


    private suspend fun restartVideoAfterUserStop() {
        if (mediaPath.isBlank()) return
        cancelHide()
        try {
            VideoStreamServerManager.startServer(applicationContext, mediaPath)
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to restart local video stream server after user stop for $mediaPath", e)
            android.widget.Toast.makeText(this, getString(R.string.error_loading_media), android.widget.Toast.LENGTH_LONG).show()
            return
        }

        try {
            startService(android.content.Intent(this, VideoPlaybackService::class.java))
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to restart VideoPlaybackService after user stop", e)
            android.widget.Toast.makeText(this, getString(R.string.error_loading_media), android.widget.Toast.LENGTH_LONG).show()
            return
        }

        try {
            controllerFuture?.let { MediaController.releaseFuture(it) }
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to release old video MediaController after user stop", e)
        }

        val token = SessionToken(this, android.content.ComponentName(this, VideoPlaybackService::class.java))
        val newFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture = newFuture
        val controller = try {
            withContext(Dispatchers.IO) { newFuture.get(6, TimeUnit.SECONDS) }
        } catch (e: Exception) {
            CrashReporter.log(this, "Failed to reconnect video MediaController after user stop", e)
            android.widget.Toast.makeText(this, getString(R.string.error_loading_media), android.widget.Toast.LENGTH_LONG).show()
            return
        }

        player = controller
        binding.playerView.player = player
        binding.playerView.setShutterBackgroundColor(android.graphics.Color.BLACK)
        binding.playerView.setBackgroundColor(android.graphics.Color.BLACK)
        playNextCalled = false
        // Après STOP puis PLAY, on relance le média comme une nouvelle ouverture :
        // le mode "demander" doit donc afficher le modal de reprise si une position existe.
        resumeHandled = false
        loadMedia(mediaPath, mediaName, 0L)
        startProgressLoop()
        showUI()
        scheduleHide()
    }

    private fun setupGestures() {
        binding.touchZoneLeft.setOnTouchListener { _, ev ->
            val h = (binding.touchZoneLeftFill.parent as View).height.toFloat().coerceAtLeast(1f)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    zoneTouching = true; cancelHide()
                    gestureStartY = ev.y; initialBrightness = getBrightness()
                }
                MotionEvent.ACTION_MOVE -> {
                    val b = (initialBrightness - (ev.y - gestureStartY) / h * 1.5f).coerceIn(0.01f, 1f)
                    setBrightness(b)
                    binding.touchZoneLeftFill.layoutParams.height = (h * b).toInt()
                    binding.touchZoneLeftFill.requestLayout()
                    binding.touchZoneLeftThumb.translationY = -h * b
                    binding.tvBrightnessZone.text = "${(b * 100).toInt()}%"
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { zoneTouching = false; scheduleHide() }
            }
            true
        }
        binding.touchZoneRight.setOnTouchListener { _, ev ->
            val h = (binding.touchZoneRightFill.parent as View).height.toFloat().coerceAtLeast(1f)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    zoneTouching = true; cancelHide()
                    gestureStartY = ev.y
                    initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                }
                MotionEvent.ACTION_MOVE -> {
                    val v = (initialVolume - ((ev.y - gestureStartY) / h * maxVolume * 1.5f).toInt()).coerceIn(0, maxVolume)
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                    val pct = v.toFloat() / maxVolume
                    binding.touchZoneRightFill.layoutParams.height = (h * pct).toInt()
                    binding.touchZoneRightFill.requestLayout()
                    binding.touchZoneRightThumb.translationY = -h * pct
                    binding.tvVolumeZone.text = "${(pct * 100).toInt()}%"
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { zoneTouching = false; scheduleHide() }
            }
            true
        }
    }

    private fun startProgressLoop() {
        lifecycleScope.launch {
            while (!isDestroyed && !isFinishing) {
                delay(500)
                if (isDestroyed || isFinishing) break
                try {
                    val dur = player.duration.takeIf { it > 0 } ?: continue
                    val pos = player.currentPosition
                    if (player.deviceInfo.playbackType != DeviceInfo.PLAYBACK_TYPE_REMOTE) {
                        lastKnownLocalPosition = pos
                    } else {
                        lastKnownRemotePosition = pos
                    }
                    if (!seekBarDragging) withContext(Dispatchers.Main) { updateProgressUI(pos, dur) }
                } catch (e: Exception) {
                    CrashReporter.log(this@PlayerActivity, "Progress loop failed", e)
                }
            }
        }
    }

    private fun updateProgressUI(pos: Long, dur: Long) {
        if (isDestroyed || isFinishing) return
        binding.tvCurrentTime.text = formatTime(pos)
        binding.tvTotalTime.text = formatTime(dur)
        val pct = (pos.toFloat() / dur).coerceIn(0f, 1f)
        val w = binding.progressContainer.width.toFloat()
        val thumbHalf = 7f * resources.displayMetrics.density
        binding.progressFill.layoutParams.width = ((w - thumbHalf * 2) * pct).toInt()
        binding.progressFill.requestLayout()
        binding.progressThumb.translationX = (w - thumbHalf * 2) * pct
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun showUI() {
        uiVisible = true
        binding.uiOverlay.visibility = View.VISIBLE
        binding.uiOverlay.animate().alpha(1f).setDuration(200).start()
        binding.touchZoneLeft.visibility = View.VISIBLE
        binding.touchZoneLeft.animate().alpha(1f).setDuration(200).start()
        binding.touchZoneRight.visibility = View.VISIBLE
        binding.touchZoneRight.animate().alpha(1f).setDuration(200).start()
        scheduleHide()
    }

    private fun hideUI() {
        if (zoneTouching || seekBarDragging) return
        uiVisible = false
        binding.uiOverlay.animate().alpha(0f).setDuration(200).withEndAction { binding.uiOverlay.visibility = View.GONE }.start()
        binding.touchZoneLeft.animate().alpha(0f).setDuration(200).withEndAction { binding.touchZoneLeft.visibility = View.GONE }.start()
        binding.touchZoneRight.animate().alpha(0f).setDuration(200).withEndAction { binding.touchZoneRight.visibility = View.GONE }.start()
    }

    private fun scheduleHide() {
        cancelHide()
        val isCasting = ::player.isInitialized && player.deviceInfo.playbackType == DeviceInfo.PLAYBACK_TYPE_REMOTE
        // Ne masque jamais les contrôles pendant un cast : pas d'image locale à voir de toute
        // façon.
        if (isCasting) return
        if (::player.isInitialized && player.isPlaying) uiHandler.postDelayed(hideRunnable, 3000)
    }

    private fun cancelHide() = uiHandler.removeCallbacks(hideRunnable)

    private fun updatePlayPauseBtn(playing: Boolean) {
        if (isDestroyed || isFinishing) return
        binding.ivPlayPause.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun getBrightness(): Float { val b = window.attributes.screenBrightness; return if (b < 0) 0.5f else b }
    private fun setBrightness(v: Float) { val lp = window.attributes; lp.screenBrightness = v; window.attributes = lp }

    /** Change de média en gardant le même player (donc la même session Cast active si on caste) :
     *  démarre le relais pour le nouveau fichier et construit un nouveau MediaItem unique. */
    private fun switchTo(path: String, name: String) {
        binding.root.animate().alpha(0f).setDuration(400).withEndAction {
            mediaPath = path
            mediaName = name
            binding.tvTitle.text = mediaName
            resumeHandled = true
            playNextCalled = false
            loadMedia(path, name)
            saveHistory()
            binding.root.alpha = 0f
            binding.root.animate().alpha(1f).setDuration(400).start()
        }.start()
    }

    private fun playNext() {
        // File d'attente de playlist ("Jouer la playlist") : prioritaire sur la logique de
        // dossier local ci-dessous, et fonctionne aussi bien pour du contenu réseau (smb://)
        // que local, contrairement au fallback MediaStore qui suit.
        if (videoQueuePaths.isNotEmpty() && videoQueueIndex < videoQueuePaths.size - 1) {
            videoQueueIndex++
            val nextPath = videoQueuePaths[videoQueueIndex]
            val nextName = videoQueueNames.getOrElse(videoQueueIndex) { File(nextPath).name }
            runOnUiThread { if (!isDestroyed && !isFinishing) switchTo(nextPath, nextName) }
            return
        }
        if (videoQueuePaths.isNotEmpty()) return // fin de la playlist, pas de fallback dossier

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val next = findAdjacentMediaStoreItem(offset = 1) ?: return@launch
                withContext(Dispatchers.Main) {
                    if (!isDestroyed && !isFinishing) switchTo(next.first, next.second)
                }
            } catch (e: Exception) {
                CrashReporter.log(this@PlayerActivity, "playNext failed", e)
            }
        }
    }

    private fun playPrevious() {
        if (videoQueuePaths.isNotEmpty() && videoQueueIndex > 0) {
            videoQueueIndex--
            val prevPath = videoQueuePaths[videoQueueIndex]
            val prevName = videoQueueNames.getOrElse(videoQueueIndex) { File(prevPath).name }
            runOnUiThread { if (!isDestroyed && !isFinishing) switchTo(prevPath, prevName) }
            return
        }
        if (videoQueuePaths.isNotEmpty()) {
            // Déjà au tout début de la playlist : redémarre juste la vidéo courante.
            if (::player.isInitialized) player.seekTo(0)
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val prev = findAdjacentMediaStoreItem(offset = -1)
                if (prev != null) {
                    withContext(Dispatchers.Main) {
                        if (!isDestroyed && !isFinishing) switchTo(prev.first, prev.second)
                    }
                } else if (::player.isInitialized) {
                    withContext(Dispatchers.Main) { player.seekTo(0) }
                }
            } catch (e: Exception) {
                CrashReporter.log(this@PlayerActivity, "playPrevious failed", e)
            }
        }
    }

    /** Cherche le fichier voisin (précédent/suivant, selon [offset]) dans le même dossier
     *  MediaStore que la vidéo courante. */
    private fun findAdjacentMediaStoreItem(offset: Int): Pair<String, String>? {
        val col = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        var curBucket = ""
        var curName = ""
        contentResolver.query(Uri.parse(mediaPath), arrayOf(
            android.provider.MediaStore.Video.Media.DISPLAY_NAME,
            android.provider.MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        ), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                curName = c.getString(0) ?: ""
                curBucket = c.getString(1) ?: ""
            }
        }
        if (curBucket.isEmpty() && curName.isEmpty()) return null

        val proj = arrayOf(
            android.provider.MediaStore.Video.Media._ID,
            android.provider.MediaStore.Video.Media.DISPLAY_NAME,
            android.provider.MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        val where = if (curBucket.isNotEmpty()) "${android.provider.MediaStore.Video.Media.BUCKET_DISPLAY_NAME} = ?" else null
        val args = if (curBucket.isNotEmpty()) arrayOf(curBucket) else null

        val list = mutableListOf<Pair<String, String>>()
        contentResolver.query(col, proj, where, args, android.provider.MediaStore.Video.Media.DISPLAY_NAME)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(c.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media._ID))
                val name = c.getString(c.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.DISPLAY_NAME)) ?: continue
                list.add(android.content.ContentUris.withAppendedId(col, id).toString() to name)
            }
        }
        val idx = list.indexOfFirst { it.second == curName }
        val targetIdx = idx + offset
        if (idx < 0 || targetIdx !in list.indices) return null
        return list[targetIdx]
    }

    private fun saveHistory() {
        val ext = mediaName.substringAfterLast('.', "").lowercase()
        val isNetwork = mediaPath.startsWith("smb://") || mediaPath.startsWith("ftp://")
        lifecycleScope.launch(Dispatchers.IO) {
            // Sauvegarde d'abord un historique minimal, sans extraction — l'extraction SMB au
            // lancement de la lecture (en parallèle de l'initialisation du service vidéo)
            // pouvait contribuer à un ANR au clic sur une vidéo. L'entrée est enrichie ensuite,
            // sans urgence, avec un délai maximal pour ne jamais bloquer indéfiniment (ex:
            // partage réseau qui répond très lentement).
            mediaRepository.saveRecentItem(fr.retrospare.blazeplayer.data.model.MediaItem(
                id = mediaPath, name = mediaName, path = mediaPath,
                extension = ext, mimeType = "video/$ext",
                isNetwork = isNetwork,
                lastPlayedAt = System.currentTimeMillis()
            ))

            val info = withTimeoutOrNull(1500) {
                VideoMetadataExtractor.extractLight(applicationContext, mediaPath)
            } ?: VideoTechnicalInfo()

            if (info.duration > 0L || info.videoCodec.isNotEmpty() || info.audioCodec.isNotEmpty()) {
                mediaRepository.saveRecentItem(fr.retrospare.blazeplayer.data.model.MediaItem(
                    id = mediaPath, name = mediaName, path = mediaPath,
                    extension = ext, mimeType = "video/$ext",
                    duration = info.duration,
                    size = info.sizeBytes,
                    resolution = info.qualityBadge,
                    videoCodec = info.videoCodec,
                    audioCodec = info.audioCodec,
                    isNetwork = isNetwork,
                    lastPlayedAt = System.currentTimeMillis()
                ))
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        enterPipIfEnabled()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            hasEnteredPip = true
            binding.uiOverlay.visibility = View.GONE
            binding.touchZoneLeft.visibility = View.GONE
            binding.touchZoneRight.visibility = View.GONE
        } else {
            hasEnteredPip = false
            showUI()
        }
    }

    private fun enterPipIfEnabled() {
        if (!prefPip) return
        if (!player.isPlaying) return
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            try { enterPictureInPictureMode(buildPipParams(autoEnter = false)) } catch (e: Exception) { CrashReporter.log(this, "enterPictureInPictureMode failed", e) }
        }
    }

    /**
     * Construit les [android.app.PictureInPictureParams] à partir du ratio vidéo réel.
     * Sur API 31+, [autoEnter] = true permet au système de déclencher automatiquement le PiP
     * lorsque l'utilisateur quitte l'app — comportement recommandé par Media3/Android.
     */
    private fun buildPipParams(autoEnter: Boolean): android.app.PictureInPictureParams {
        val videoSize = player.videoSize
        val rational = if (videoSize.width > 0 && videoSize.height > 0) {
            val r = android.util.Rational(videoSize.width, videoSize.height)
            val float = videoSize.width.toFloat() / videoSize.height
            if (float < 0.418f) android.util.Rational(1, 2)
            else if (float > 2.39f) android.util.Rational(239, 100)
            else r
        } else android.util.Rational(16, 9)

        val builder = android.app.PictureInPictureParams.Builder().setAspectRatio(rational)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(autoEnter && prefPip && player.isPlaying)
        }
        return builder.build()
    }

    private fun updatePipParamsIfSupported() {
        if (!::player.isInitialized) return
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) return
        try { setPictureInPictureParams(buildPipParams(autoEnter = true)) } catch (e: Exception) { CrashReporter.log(this, "setPictureInPictureParams failed", e) }
    }
}
