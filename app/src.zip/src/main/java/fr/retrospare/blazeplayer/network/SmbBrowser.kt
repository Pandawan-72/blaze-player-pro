package fr.retrospare.blazeplayer.network

import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.share.DiskShare
import fr.retrospare.blazeplayer.data.model.MediaItem
import fr.retrospare.blazeplayer.data.model.NetworkShare
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SmbBrowser @Inject constructor() {

    private val VIDEO_EXTENSIONS = setOf(
        "mp4", "mkv", "avi", "mov", "wmv", "flv", "ts",
        "m4v", "webm", "mpg", "mpeg", "3gp", "divx"
    )

    private val AUDIO_EXTENSIONS = setOf(
        "mp3", "flac", "aac", "ogg", "opus", "wav", "m4a", "wma", "ape", "dts", "ac3", "mka"
    )

    private fun createClient(): SMBClient {
        val config = SmbConfig.builder()
            .withTimeout(30, TimeUnit.SECONDS)
            .withReadTimeout(60, TimeUnit.SECONDS)
            .build()
        return SMBClient(config)
    }

    /** Client dédié aux recherches récursives, avec des délais bien plus courts que
     *  [createClient]. Un parcours récursif enchaîne potentiellement des dizaines d'appels —
     *  avec les délais habituels (jusqu'à 60s en lecture), un seul appel isolé qui traîne peut
     *  faire paraître toute la recherche figée. Volontairement séparé de [createClient] pour ne
     *  jamais affecter la navigation normale, qui continue d'utiliser les délais généreux
     *  habituels. */
    private fun createSearchClient(): SMBClient {
        val config = SmbConfig.builder()
            .withTimeout(8, TimeUnit.SECONDS)
            .withReadTimeout(12, TimeUnit.SECONDS)
            .build()
        return SMBClient(config)
    }

    /**
     * Liste les partages SMB disponibles sur l'hote (racine du NAS).
     * Utilise quand share.shareName est vide.
     */
    suspend fun listShares(share: NetworkShare): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        runCatching {
            val client = createClient()
            val authContext = buildAuthContext(share)
            val items = mutableListOf<MediaItem>()

            client.connect(share.host, share.port ?: 445).use { connection ->
                val session = connection.authenticate(authContext)
                try {
                    val transport = com.rapid7.client.dcerpc.transport.SMBTransportFactories.SRVSVC.getTransport(session)
                    val serverService = com.rapid7.client.dcerpc.mssrvs.ServerService(transport)
                    val shares = serverService.shares0
                    shares.forEach { shareInfo ->
                        val name = shareInfo.netName
                        // Filtre les shares administratifs (ADMIN$, C$, IPC$...) et types non disque
                        if (!name.endsWith("$") && name.isNotBlank()) {
                            items.add(
                                MediaItem(
                                    id = "smb://${share.host}/$name",
                                    name = name,
                                    path = name,
                                    mimeType = "share",
                                    extension = "",
                                    isNetwork = true,
                                    networkShareId = share.id
                                )
                            )
                        }
                    }
                } finally {
                    session.close()
                }
            }
            items.sortBy { it.name.lowercase() }
            items
        }
    }

    suspend fun listFiles(
        share: NetworkShare,
        path: String = ""
    ): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        // Si aucun nom de partage n'est defini, on liste les partages disponibles
        if (share.shareName.isBlank()) {
            // Le chemin "path" sert alors a stocker le nom du partage choisi + sous-chemin
            if (path.isBlank()) {
                return@withContext listShares(share)
            }
            val parts = path.split("/", limit = 2)
            val actualShareName = parts[0]
            val actualPath = if (parts.size > 1) parts[1] else ""
            return@withContext listFilesInShare(share.copy(shareName = actualShareName), actualPath, actualShareName)
        }
        listFilesInShare(share, path, null)
    }

    private suspend fun listFilesInShare(
        share: NetworkShare,
        path: String,
        sharePrefix: String?
    ): Result<List<MediaItem>> = withContext(Dispatchers.IO) {
        runCatching {
            val client = createClient()
            val authContext = buildAuthContext(share)
            val host = share.host
            val port = share.port ?: 445
            val items = mutableListOf<MediaItem>()

            client.connect(host, port).use { connection ->
                connection.authenticate(authContext).use { session ->
                    (session.connectShare(share.shareName) as? DiskShare)?.use { diskShare ->
                        // [path] est toujours en '/' ici (séparateur canonique côté app) ; la
                        // conversion en '\' — celui attendu par le protocole SMB — n'a lieu
                        // qu'à cet unique endroit, juste avant l'appel réseau. Mélanger les deux
                        // séparateurs plus loin dans la construction des chemins causait des
                        // dossiers introuvables lors de la navigation dans un partage
                        // auto-détecté (mode multi-partages).
                        val smbSearchPath = path.replace("/", "\\")
                        val entries = diskShare.list(smbSearchPath)

                        entries.forEach { info ->
                            val name = info.fileName
                            if (name == "." || name == "..") return@forEach
                            if (name.startsWith(".")) return@forEach

                            // fullPath reste en '/' (canonique) pour l'affichage et la
                            // navigation ultérieure — jamais mélangé avec des '\'.
                            val fullPath = if (path.isEmpty()) name else "$path/$name"
                            val isDir = info.fileAttributes and 0x10L != 0L
                            val ext = name.substringAfterLast('.', "").lowercase()
                            // Si on navigue en mode multi-share, le "path" affiche au niveau superieur doit inclure le nom du partage
                            val displayPath = if (sharePrefix != null) "$sharePrefix/$fullPath" else fullPath

                            if (isDir) {
                                items.add(
                                    MediaItem(
                                        id = "smb://$host/${share.shareName}/$fullPath",
                                        name = name,
                                        path = displayPath,
                                        mimeType = "folder",
                                        extension = "",
                                        isNetwork = true,
                                        networkShareId = share.id
                                    )
                                )
                            } else if (ext in VIDEO_EXTENSIONS || ext in AUDIO_EXTENSIONS) {
                                val smbUri = buildSmbUri(share, fullPath)
                                items.add(
                                    MediaItem(
                                        id = smbUri,
                                        name = name,
                                        path = smbUri,
                                        size = info.endOfFile,
                                        mimeType = getMimeType(ext),
                                        extension = ext,
                                        isNetwork = true,
                                        networkShareId = share.id
                                    )
                                )
                            }
                        }
                    }
                }
            }
            items.sortWith(compareBy({ it.mimeType != "folder" }, { it.name.lowercase() }))
            items
        }
    }

    /**
     * Recherche récursive de tous les fichiers audio dans un partage réseau, à partir de
     * [startPath] (racine par défaut). Garde UNE SEULE connexion/session SMB ouverte pour tout
     * le parcours, avec un budget de temps global et une gestion résiliente des erreurs : une
     * panne sur un sous-dossier ne fait pas perdre les résultats déjà trouvés ailleurs.
     */
    suspend fun searchAudioRecursive(share: NetworkShare, startPath: String = ""): Result<List<MediaItem>> =
        withContext(Dispatchers.IO) {
            val results = mutableListOf<MediaItem>()
            val deadline = System.currentTimeMillis() + 45_000L
            var caughtError: Exception? = null
            try {
                val client = createSearchClient()
                val authContext = buildAuthContext(share)

                client.connect(share.host, share.port ?: 445).use { connection ->
                    connection.authenticate(authContext).use { session ->
                        if (share.shareName.isBlank()) {
                            val shareNames = try {
                                val transport = com.rapid7.client.dcerpc.transport.SMBTransportFactories.SRVSVC.getTransport(session)
                                val serverService = com.rapid7.client.dcerpc.mssrvs.ServerService(transport)
                                serverService.shares0
                                    .map { it.netName }
                                    .filter { !it.endsWith("$") && it.isNotBlank() }
                            } catch (e: Exception) {
                                caughtError = e
                                emptyList()
                            }
                            for (shareName in shareNames) {
                                if (System.currentTimeMillis() > deadline) break
                                try {
                                    (session.connectShare(shareName) as? DiskShare)?.use { diskShare ->
                                        walkDiskShareForAudio(diskShare, "", share, shareName, results, depth = 0, deadline = deadline, onError = { caughtError = it })
                                    }
                                } catch (e: Exception) {
                                    caughtError = e
                                    // Continue avec les autres partages même si celui-ci échoue
                                }
                            }
                        } else {
                            val connected = session.connectShare(share.shareName)
                            val diskShare = connected as? DiskShare
                            if (diskShare != null) {
                                diskShare.use {
                                    walkDiskShareForAudio(it, startPath, share, share.shareName, results, depth = 0, deadline = deadline, onError = { err -> caughtError = err })
                                }
                            } else {
                                caughtError = Exception("connectShare(\"${share.shareName}\") n'a pas retourné de DiskShare valide (type reçu : ${connected?.javaClass?.simpleName ?: "null"})")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                caughtError = e
                android.util.Log.w("SmbBrowser", "searchAudioRecursive: erreur pendant le scan, retour des résultats partiels (${results.size})", e)
            }
            // Si on n'a rien trouvé ET qu'une erreur s'est produite, on la remonte plutôt que
            // de simplement dire "0 résultat" — ça permet de distinguer "il n'y a vraiment
            // rien" de "la connexion/le scan a échoué quelque part".
            if (results.isEmpty() && caughtError != null) Result.failure(caughtError!!) else Result.success(results)
        }

    /** Parcourt récursivement un [DiskShare] déjà connecté et ajoute tous les fichiers audio
     *  trouvés à [results]. Limite de profondeur et [deadline] pour ne jamais bloquer
     *  indéfiniment. */
    private fun walkDiskShareForAudio(
        diskShare: DiskShare,
        path: String,
        share: NetworkShare,
        shareName: String,
        results: MutableList<MediaItem>,
        depth: Int,
        deadline: Long,
        onError: (Exception) -> Unit = {}
    ) {
        if (depth > 12) return
        if (System.currentTimeMillis() > deadline) return
        // [path] est toujours en '/' ici (canonique) — conversion en '\' uniquement pour
        // l'appel SMB lui-même, comme dans listFilesInShare.
        val entries = try {
            diskShare.list(path.replace("/", "\\"))
        } catch (e: Exception) {
            onError(e)
            return
        }
        for (info in entries) {
            if (System.currentTimeMillis() > deadline) return
            val name = info.fileName
            if (name == "." || name == "..") continue
            if (name.startsWith(".")) continue
            val fullPath = if (path.isEmpty()) name else "$path/$name"
            val isDir = info.fileAttributes and 0x10L != 0L
            if (isDir) {
                walkDiskShareForAudio(diskShare, fullPath, share, shareName, results, depth + 1, deadline, onError)
            } else {
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in AUDIO_EXTENSIONS) {
                    val smbUri = buildSmbUri(share.copy(shareName = shareName), fullPath)
                    results.add(
                        MediaItem(
                            id = smbUri,
                            name = name,
                            path = smbUri,
                            size = info.endOfFile,
                            mimeType = getMimeType(ext),
                            extension = ext,
                            isNetwork = true,
                            networkShareId = share.id
                        )
                    )
                }
            }
        }
    }

    suspend fun checkConnection(share: NetworkShare): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val client = createClient()
            val authContext = buildAuthContext(share)
            client.connect(share.host, share.port ?: 445).use { connection ->
                connection.authenticate(authContext).use { session ->
                    session.connectShare(share.shareName) != null
                }
            }
        }.getOrDefault(false)
    }

    private fun buildAuthContext(share: NetworkShare): AuthenticationContext {
        return if (!share.username.isNullOrEmpty()) {
            AuthenticationContext(
                share.username,
                (share.password ?: "").toCharArray(),
                ""
            )
        } else {
            AuthenticationContext.anonymous()
        }
    }

    private fun buildSmbUri(share: NetworkShare, path: String): String {
        val cleanPath = path.replace("\\", "/")
        val auth = if (!share.username.isNullOrEmpty()) {
            val pass = share.password?.let { ":${java.net.URLEncoder.encode(it, "UTF-8")}" } ?: ""
            "${java.net.URLEncoder.encode(share.username, "UTF-8")}$pass@"
        } else ""
        val port = if (share.port != null && share.port != 445) ":${share.port}" else ""
        return "smb://$auth${share.host}$port/${share.shareName}/$cleanPath"
    }

    private fun getMimeType(ext: String): String = when (ext) {
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "avi" -> "video/x-msvideo"
        "mov" -> "video/quicktime"
        "ts" -> "video/mp2ts"
        "flv" -> "video/x-flv"
        "wmv" -> "video/x-ms-wmv"
        "webm" -> "video/webm"
        "mp3" -> "audio/mpeg"
        "flac" -> "audio/flac"
        "aac" -> "audio/aac"
        "ogg", "opus" -> "audio/ogg"
        "wav" -> "audio/wav"
        "m4a" -> "audio/mp4"
        "wma" -> "audio/x-ms-wma"
        "ape" -> "audio/x-ape"
        "dts" -> "audio/vnd.dts"
        "ac3" -> "audio/ac3"
        "mka" -> "audio/x-matroska"
        else -> if (ext in AUDIO_EXTENSIONS) "audio/*" else "video/*"
    }
}
