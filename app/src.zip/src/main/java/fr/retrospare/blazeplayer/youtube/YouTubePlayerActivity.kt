package fr.retrospare.blazeplayer.youtube

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.lifecycle.lifecycleScope
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import kotlinx.coroutines.flow.first
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import fr.retrospare.blazeplayer.R

/** Lecteur YouTube — utilise android-youtube-player (MIT, PierfrancescoSoffritti), une
 *  bibliothèque éprouvée qui embarque le lecteur officiel IFrame de Google et gère en interne
 *  toute la configuration WebView/referrer nécessaire. Trois tentatives de WebView maison ont
 *  toutes échoué avec des erreurs 150/152/153 (validation d'intégration YouTube), un problème
 *  bien connu que cette bibliothèque résout spécifiquement. On n'extrait toujours JAMAIS l'URL du
 *  flux vidéo brut pour la lire dans Media3/ExoPlayer : cela violerait les CGU de YouTube — cette
 *  activité affiche uniquement le lecteur officiel. En quittant, on revient naturellement sur
 *  l'onglet Blaze Tube déjà actif dans HomeFragment.
 *
 *  Support de la navigation suivant/précédent quand la vidéo fait partie d'une playlist Blaze
 *  Tube (1/2/3) : la liste complète des ids/titres est transmise via Intent, et un seul
 *  YouTubePlayer est réutilisé pour charger la vidéo suivante/précédente sans réinitialiser toute
 *  l'activité (recharge juste la vidéo affichée, garde le lecteur natif ouvert).
 *
 *  Support du mode PiP (image dans l'image) : en quittant l'app pendant la lecture (bouton
 *  Accueil, changement d'app), la vidéo continue dans une petite fenêtre flottante par-dessus le
 *  reste du système, plutôt que de s'arrêter. Nos propres boutons (fermer, précédent, suivant)
 *  sont masqués dans ce mode — trop petit pour être utilisables, et Android fournit déjà ses
 *  propres contrôles de fenêtre PiP par-dessus.
 *
 *  Notification Android : le lecteur YouTube tourne dans une WebView (pas Media3/ExoPlayer), donc
 *  pas de MediaSessionService automatique comme pour la vidéo locale/réseau. Une MediaSessionCompat
 *  "manuelle" pilote ici une notification MediaStyle (titre, chaîne, miniature, lecture/pause, et
 *  précédent/suivant si on est dans une playlist), affichée pendant que l'activité est active. */
@AndroidEntryPoint
class YouTubePlayerActivity : AppCompatActivity() {

    @Inject lateinit var dataStore: DataStore<Preferences>

    private lateinit var youTubePlayerView: YouTubePlayerView
    private var youTubePlayer: YouTubePlayer? = null
    private var isCurrentlyPlaying = false
    private var prefPip = false

    private var playlistIds: List<String> = emptyList()
    private var playlistTitles: List<String> = emptyList()
    private var currentIndex: Int = -1

    private lateinit var mediaSession: MediaSessionCompat
    private var notificationThumbnail: Bitmap? = null
    private var notificationTitle: String = ""
    private var notificationChannel: String = ""

    companion object {
        const val EXTRA_VIDEO_ID = "videoId"
        const val EXTRA_TITLE = "title"
        const val EXTRA_CHANNEL = "channel"
        const val EXTRA_THUMBNAIL = "thumbnail"
        const val EXTRA_PLAYLIST_IDS = "playlistIds"
        const val EXTRA_PLAYLIST_TITLES = "playlistTitles"
        const val EXTRA_PLAYLIST_INDEX = "playlistIndex"

        private const val NOTIFICATION_ID = 2003
        private const val NOTIF_CHANNEL_ID = "blaze_youtube_channel"

        // Actions de la notification : gérées par un BroadcastReceiver enregistré
        // dynamiquement (voir setupNotificationActionReceiver) plutôt que par
        // androidx.media.session.MediaButtonReceiver, qui suppose une
        // MediaBrowserServiceCompat qu'on n'a pas ici (lecteur en WebView, pas de Service).
        private const val ACTION_PLAY = "fr.retrospare.blazeplayer.youtube.PLAY"
        private const val ACTION_PAUSE = "fr.retrospare.blazeplayer.youtube.PAUSE"
        private const val ACTION_NEXT = "fr.retrospare.blazeplayer.youtube.NEXT"
        private const val ACTION_PREVIOUS = "fr.retrospare.blazeplayer.youtube.PREVIOUS"
    }

    private val notificationActionReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_PLAY -> youTubePlayer?.play()
                ACTION_PAUSE -> youTubePlayer?.pause()
                ACTION_NEXT -> if (hasNext()) goToRelative(1)
                ACTION_PREVIOUS -> if (hasPrevious()) goToRelative(-1)
            }
        }
    }

    private fun actionPendingIntent(action: String): PendingIntent =
        PendingIntent.getBroadcast(
            this, action.hashCode(),
            Intent(action).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Mode immersif complet : l'ancien FLAG_FULLSCREEN ne masquait que la barre de statut,
        // pas la barre de navigation système, qui rognait les contrôles du lecteur YouTube en
        // bas de l'écran. WindowInsetsControllerCompat masque les deux, avec réapparition
        // temporaire au balayage (comportement standard des lecteurs vidéo plein écran).
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_youtube_player)
        val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        insetsController.systemBarsBehavior =
            androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val videoId = intent.getStringExtra(EXTRA_VIDEO_ID)
        if (videoId.isNullOrBlank()) {
            finish()
            return
        }

        playlistIds = intent.getStringArrayExtra(EXTRA_PLAYLIST_IDS)?.toList().orEmpty()
        playlistTitles = intent.getStringArrayExtra(EXTRA_PLAYLIST_TITLES)?.toList().orEmpty()
        currentIndex = intent.getIntExtra(EXTRA_PLAYLIST_INDEX, -1)

        createNotificationChannel()
        setupMediaSession()
        registerNotificationActionReceiver()

        lifecycleScope.launch {
            try {
                prefPip = dataStore.data.first()[booleanPreferencesKey("pip")] ?: false
            } catch (e: Exception) {
                android.util.Log.w("YouTubePlayerActivity", "Lecture préférence PiP impossible", e)
                prefPip = false
            }
        }

        youTubePlayerView = findViewById(R.id.youtubePlayerView)
        lifecycle.addObserver(youTubePlayerView)

        youTubePlayerView.initialize(object : AbstractYouTubePlayerListener() {
            override fun onReady(player: YouTubePlayer) {
                youTubePlayer = player
                player.loadVideo(videoId, 0f)
                val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
                val channel = intent.getStringExtra(EXTRA_CHANNEL).orEmpty()
                val thumbnail = intent.getStringExtra(EXTRA_THUMBNAIL).orEmpty()
                addCurrentToHistory(videoId, title, channel, thumbnail)
                updateNotificationMetadata(title, channel, thumbnail)
            }

            override fun onStateChange(player: YouTubePlayer, state: PlayerConstants.PlayerState) {
                isCurrentlyPlaying = state == PlayerConstants.PlayerState.PLAYING
                updatePlaybackState()
                if (state == PlayerConstants.PlayerState.ENDED) {
                    // Enchaîne automatiquement sur la suivante si on est dans une playlist,
                    // sinon ferme comme avant.
                    if (hasNext()) goToRelative(1) else finish()
                }
            }

            override fun onError(player: YouTubePlayer, error: PlayerConstants.PlayerError) {
                android.util.Log.e("YouTubePlayerActivity", "Erreur lecteur YouTube : $error")
            }
        })

        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }

        setupPlaylistNavigation()
    }

    private fun hasPrevious(): Boolean = playlistIds.size > 1 && currentIndex > 0
    private fun hasNext(): Boolean = playlistIds.size > 1 && currentIndex < playlistIds.size - 1

    private fun setupPlaylistNavigation() {
        val btnPrevious = findViewById<View>(R.id.btnYoutubePrevious)
        val btnNext = findViewById<View>(R.id.btnYoutubeNext)
        if (playlistIds.size <= 1 || currentIndex < 0) {
            btnPrevious.visibility = View.GONE
            btnNext.visibility = View.GONE
            return
        }
        btnPrevious.visibility = View.VISIBLE
        btnNext.visibility = View.VISIBLE
        updateNavigationButtonsState()
        btnPrevious.setOnClickListener { if (hasPrevious()) goToRelative(-1) }
        btnNext.setOnClickListener { if (hasNext()) goToRelative(1) }
    }

    private fun updateNavigationButtonsState() {
        findViewById<View>(R.id.btnYoutubePrevious).apply {
            isEnabled = hasPrevious()
            alpha = if (hasPrevious()) 1f else 0.35f
        }
        findViewById<View>(R.id.btnYoutubeNext).apply {
            isEnabled = hasNext()
            alpha = if (hasNext()) 1f else 0.35f
        }
    }

    private fun goToRelative(delta: Int) {
        val newIndex = currentIndex + delta
        if (newIndex !in playlistIds.indices) return
        currentIndex = newIndex
        val videoId = playlistIds[newIndex]
        val title = playlistTitles.getOrElse(newIndex) { "" }
        val enriched = YouTubeLibrary.enrichFromCache(this, YouTubeVideoItem(videoId = videoId, title = title, channelTitle = "", thumbnailUrl = ""))
        youTubePlayer?.loadVideo(enriched.videoId, 0f)
        addCurrentToHistory(enriched.videoId, enriched.title, enriched.channelTitle, enriched.thumbnailUrl)
        updateNavigationButtonsState()
        updateNotificationMetadata(enriched.title, enriched.channelTitle, enriched.thumbnailUrl)
    }

    private fun addCurrentToHistory(videoId: String, title: String, channel: String, thumbnail: String) {
        // Historique : enregistré à l'ouverture de chaque vidéo (y compris lors d'un
        // suivant/précédent), même logique que l'historique local/réseau existant, qui trace
        // l'ouverture, pas le visionnage complet.
        YouTubeLibrary.addToHistory(
            this,
            YouTubeVideoItem(videoId = videoId, title = title, channelTitle = channel, thumbnailUrl = thumbnail)
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(NOTIF_CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            NOTIF_CHANNEL_ID,
            getString(R.string.notif_channel_youtube),
            NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)
    }

    /** MediaSessionCompat "manuelle" : il n'y a pas de Player Media3 ici (WebView), donc pas de
     *  MediaSessionService automatique — cette session pilote juste la notification MediaStyle
     *  et reçoit les actions lecture/pause/suivant/précédent tapées depuis la notification ou un
     *  bouton casque/Bluetooth. */
    private fun setupMediaSession() {
        mediaSession = MediaSessionCompat(this, "BlazeTubeSession").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { youTubePlayer?.play() }
                override fun onPause() { youTubePlayer?.pause() }
                override fun onSkipToNext() { if (hasNext()) goToRelative(1) }
                override fun onSkipToPrevious() { if (hasPrevious()) goToRelative(-1) }
            })
            isActive = true
        }
    }

    private fun registerNotificationActionReceiver() {
        val filter = android.content.IntentFilter().apply {
            addAction(ACTION_PLAY)
            addAction(ACTION_PAUSE)
            addAction(ACTION_NEXT)
            addAction(ACTION_PREVIOUS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(notificationActionReceiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(notificationActionReceiver, filter)
        }
    }

    private fun updateNotificationMetadata(title: String, channel: String, thumbnailUrl: String) {
        notificationTitle = title
        notificationChannel = channel
        notificationThumbnail = null
        showNotification()

        if (thumbnailUrl.isBlank()) return
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val bitmap = try {
                val loader = applicationContext.imageLoader
                val request = ImageRequest.Builder(applicationContext)
                    .data(thumbnailUrl)
                    .allowHardware(false) // requis : un bitmap "hardware" ne peut pas être utilisé dans une notification
                    .build()
                val result = loader.execute(request)
                (result.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap
            } catch (e: Exception) {
                null
            }
            if (bitmap != null) {
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    // La vidéo a pu changer entre-temps (suivant/précédent rapide) : ne met à
                    // jour que si le titre correspond toujours à ce qu'on vient de charger.
                    if (notificationTitle == title) {
                        notificationThumbnail = bitmap
                        showNotification()
                    }
                }
            }
        }
    }

    private fun updatePlaybackState() {
        val state = if (isCurrentlyPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        val actions = PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            (if (hasNext()) PlaybackStateCompat.ACTION_SKIP_TO_NEXT else 0L) or
            (if (hasPrevious()) PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS else 0L)
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1f)
                .build()
        )
        showNotification()
    }

    private fun showNotification() {
        if (!::mediaSession.isInitialized) return
        mediaSession.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, notificationTitle)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, notificationChannel)
                .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, notificationThumbnail)
                .build()
        )

        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, YouTubePlayerActivity::class.java).apply {
                putExtra(EXTRA_VIDEO_ID, playlistIds.getOrNull(currentIndex) ?: intent.getStringExtra(EXTRA_VIDEO_ID))
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIcon = if (isCurrentlyPlaying) R.drawable.ic_pause else R.drawable.ic_play
        val playPauseAction = NotificationCompat.Action(
            playPauseIcon,
            getString(if (isCurrentlyPlaying) R.string.action_pause else R.string.action_play),
            actionPendingIntent(if (isCurrentlyPlaying) ACTION_PAUSE else ACTION_PLAY)
        )

        val builder = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_play_circle)
            .setContentTitle(notificationTitle)
            .setContentText(notificationChannel)
            .setLargeIcon(notificationThumbnail)
            .setContentIntent(contentIntent)
            .setOngoing(isCurrentlyPlaying)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (hasPrevious()) {
            builder.addAction(
                R.drawable.ic_skip_previous,
                getString(R.string.content_desc_previous),
                actionPendingIntent(ACTION_PREVIOUS)
            )
        }
        builder.addAction(playPauseAction)
        if (hasNext()) {
            builder.addAction(
                R.drawable.ic_skip_next,
                getString(R.string.content_desc_next),
                actionPendingIntent(ACTION_NEXT)
            )
        }

        val style = androidx.media.app.NotificationCompat.MediaStyle()
            .setMediaSession(mediaSession.sessionToken)
            .setShowActionsInCompactView(if (hasPrevious()) 1 else 0, if (hasNext()) (if (hasPrevious()) 2 else 1) else -1)
        builder.setStyle(style)

        try {
            androidx.core.app.NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, builder.build())
        } catch (e: SecurityException) {
            android.util.Log.w("YouTubePlayerActivity", "Permission de notification refusée", e)
        }
    }

    override fun onDestroy() {
        try { youTubePlayer?.pause() } catch (e: Exception) {
            android.util.Log.w("YouTubePlayerActivity", "Échec pause lecteur YouTube en fermeture", e)
        }
        super.onDestroy()
        try {
            androidx.core.app.NotificationManagerCompat.from(this).cancel(NOTIFICATION_ID)
        } catch (e: Exception) {
            android.util.Log.w("YouTubePlayerActivity", "Échec annulation notification", e)
        }
        try {
            unregisterReceiver(notificationActionReceiver)
        } catch (e: Exception) {
            android.util.Log.w("YouTubePlayerActivity", "Échec désenregistrement du receiver", e)
        }
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    /** Appelé quand l'utilisateur quitte l'app (bouton Accueil, changement d'app récente) — PAS
     *  au bouton retour, qui doit continuer à fermer normalement. Bascule en PiP si une vidéo est
     *  activement en cours de lecture. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (prefPip && isCurrentlyPlaying && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(buildPipParams())
            } catch (e: Exception) {
                android.util.Log.w("YouTubePlayerActivity", "Échec entrée en PiP", e)
            }
        }
    }

    private fun buildPipParams(): android.app.PictureInPictureParams =
        android.app.PictureInPictureParams.Builder()
            .setAspectRatio(android.util.Rational(16, 9))
            .build()

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        // Nos boutons (fermer, précédent, suivant) n'ont pas leur place dans la petite fenêtre
        // PiP : Android affiche déjà ses propres contrôles de fenêtre par-dessus.
        val visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        findViewById<View>(R.id.btnClose).visibility = visibility
        if (playlistIds.size > 1 && currentIndex >= 0) {
            findViewById<View>(R.id.btnYoutubePrevious).visibility = visibility
            findViewById<View>(R.id.btnYoutubeNext).visibility = visibility
        }
    }
}
