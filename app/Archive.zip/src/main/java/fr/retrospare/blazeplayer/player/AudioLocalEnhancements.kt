package fr.retrospare.blazeplayer.player

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/** Paroles locales + métadonnées utilisateur non destructives.
 *  Le tag editor Pro+ sauvegarde des overrides locaux pour l'affichage et la bibliothèque sans
 *  réécrire physiquement les fichiers audio (plus sûr avec Android/SAF/SMB). */
object AudioLocalEnhancements {
    private const val PREFS_META = "blaze_audio_metadata_overrides"

    data class MetadataOverride(
        val title: String = "",
        val artist: String = "",
        val album: String = ""
    )

    data class LyricLine(val timeMs: Long, val text: String)

    fun key(path: String): String {
        val digest = MessageDigest.getInstance("MD5").digest(path.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun getOverride(context: Context, path: String): MetadataOverride? {
        if (path.isBlank()) return null
        val raw = context.applicationContext.getSharedPreferences(PREFS_META, Context.MODE_PRIVATE)
            .getString(key(path), null) ?: return null
        val parts = raw.split("\u0001", limit = 3)
        return MetadataOverride(
            title = parts.getOrNull(0).orEmpty(),
            artist = parts.getOrNull(1).orEmpty(),
            album = parts.getOrNull(2).orEmpty()
        ).takeIf { it.title.isNotBlank() || it.artist.isNotBlank() || it.album.isNotBlank() }
    }

    fun saveOverride(context: Context, path: String, override: MetadataOverride) {
        if (path.isBlank()) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS_META, Context.MODE_PRIVATE)
        val clean = MetadataOverride(override.title.trim(), override.artist.trim(), override.album.trim())
        val edit = prefs.edit()
        if (clean.title.isBlank() && clean.artist.isBlank() && clean.album.isBlank()) {
            edit.remove(key(path))
        } else {
            edit.putString(key(path), listOf(clean.title, clean.artist, clean.album).joinToString("\u0001"))
        }
        edit.apply()
    }

    fun applyOverride(context: Context, path: String, title: String, artist: String, album: String): MetadataOverride {
        val override = getOverride(context, path)
        return MetadataOverride(
            title = override?.title?.takeIf { it.isNotBlank() } ?: title,
            artist = override?.artist?.takeIf { it.isNotBlank() } ?: artist,
            album = override?.album?.takeIf { it.isNotBlank() } ?: album
        )
    }

    fun findLocalLyrics(context: Context, path: String): List<LyricLine> {
        if (!AudioProSettings.read(context).syncedLyrics) return emptyList()
        if (path.startsWith("smb://", true) || path.startsWith("http://", true) || path.startsWith("content://", true)) return emptyList()
        val file = when {
            path.startsWith("file://", true) -> File(android.net.Uri.parse(path).path.orEmpty())
            else -> File(path)
        }
        val base = file.name.substringBeforeLast('.', file.name)
        val dir = file.parentFile ?: return emptyList()
        val candidates = listOf(File(dir, "$base.lrc"), File(dir, "$base.LRC"), File(dir, "$base.txt"), File(dir, "$base.TXT"))
        val lyricsFile = candidates.firstOrNull { it.exists() && it.isFile && it.length() in 1..512_000 } ?: return emptyList()
        val text = runCatching { lyricsFile.readText(Charsets.UTF_8) }.getOrNull()
            ?: runCatching { lyricsFile.readText(Charsets.ISO_8859_1) }.getOrNull()
            ?: return emptyList()
        return if (lyricsFile.extension.lowercase(Locale.ROOT) == "lrc") parseLrc(text) else {
            val plain = text.lineSequence().map { it.trim() }.filter { it.isNotBlank() }.take(80).joinToString("  •  ")
            if (plain.isBlank()) emptyList() else listOf(LyricLine(0L, plain.take(240)))
        }
    }

    private fun parseLrc(text: String): List<LyricLine> {
        val regex = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\]")
        val result = mutableListOf<LyricLine>()
        text.lineSequence().forEach { raw ->
            val matches = regex.findAll(raw).toList()
            if (matches.isEmpty()) return@forEach
            val lyric = raw.replace(regex, "").trim()
            if (lyric.isBlank()) return@forEach
            matches.forEach { m ->
                val min = m.groupValues.getOrNull(1)?.toLongOrNull() ?: 0L
                val sec = m.groupValues.getOrNull(2)?.toLongOrNull() ?: 0L
                val fracRaw = m.groupValues.getOrNull(3).orEmpty()
                val ms = when (fracRaw.length) { 1 -> fracRaw.toLongOrNull()?.times(100) ?: 0L; 2 -> fracRaw.toLongOrNull()?.times(10) ?: 0L; else -> fracRaw.take(3).toLongOrNull() ?: 0L }
                result += LyricLine((min * 60_000L) + (sec * 1000L) + ms, lyric)
            }
        }
        return result.sortedBy { it.timeMs }.take(10_000)
    }

    fun lineForPosition(lines: List<LyricLine>, positionMs: Long): String? {
        if (lines.isEmpty()) return null
        var best: LyricLine? = null
        for (line in lines) {
            if (line.timeMs <= positionMs + 250L) best = line else break
        }
        return best?.text ?: lines.firstOrNull { it.timeMs <= 1000L }?.text
    }
}
